echo "----------------------- downloading COCO cow dataset -----------------------"
wget https://download.cs.stanford.edu/viscam/AnimalKingdom/magicpony/data/cow_coco.zip && unzip -q cow_coco.zip