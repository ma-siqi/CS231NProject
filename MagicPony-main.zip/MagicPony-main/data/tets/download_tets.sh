echo "----------------------- downloading tetrahedral grids -----------------------"
wget https://download.cs.stanford.edu/viscam/AnimalKingdom/magicpony/data/tets.zip && unzip -q tets.zip