Place the tet grid files in this folder. 
We provide a few example grids. See the main README.md for a download link.

You can also generate your own grids using https://github.com/crawforddoran/quartet 
Please see the `generate_tets.py` script for an example. 

