from .utils.misc import setup_runtime
from .trainer import Trainer
from .model import MagicPony
